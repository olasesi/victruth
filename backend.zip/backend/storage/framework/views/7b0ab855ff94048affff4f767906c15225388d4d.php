<?php $__env->startComponent('mail::message'); ?>
# Reset Your Password

Hello,

We received a request to reset your password. If you didn't make this request, you can ignore this email. Otherwise,
please click the button below to reset your password:

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/customer-enter-new-password/'.$email_verification_code['verification-code']]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

This link will expire in 1 hour for security reasons. If you continue to have trouble, please contact our support team.

Thank you!

Sincerely,<br>
The Victruth Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\victruth\backend\resources\views\emails\users\forgetpasswordcustomer.blade.php ENDPATH**/ ?>