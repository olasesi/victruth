<?php $__env->startComponent('mail::message'); ?>
# Message from <?php echo e($messages['fullname']); ?>

# <?php echo e($messages['sender_email']); ?>


The body of message:

<?php echo e($messages['message']); ?>



Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\victruth\backend\resources\views/emails/users/messageus.blade.php ENDPATH**/ ?>