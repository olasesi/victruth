<?php $__env->startComponent('mail::message'); ?>
# Order Confirmation

Dear <?php echo e($payment_verification['name']); ?>,

We are excited to confirm your recent order with Victruth. Your order details are as follows:

**Reference Number:** <?php echo e($payment_verification['reference']); ?>

**Order Date:** <?php echo e($payment_verification['orders']['created_at']); ?>


**Items Ordered:**
- Limo Ride: <?php echo e($getCustomer['orders']->limo_ride == 1 ? 'Yes' : '-'); ?>

- Event Planners: <?php echo e($getCustomer['orders']->event_planners == 1 ? 'Yes' : '-'); ?>

- Caterers: <?php echo e($getCustomer['orders']->caterers == 1 ? 'Yes' : '-'); ?>

- Cakes: <?php echo e($getCustomer['orders']->cakes == 1 ? 'Yes' : '-'); ?>

- Drink Suppliers: <?php echo e($getCustomer['orders']->drink_suppliers == 1 ? 'Yes' : '-'); ?>

- Servers/Waiters: <?php echo e($getCustomer['orders']->servers_waiters == 1 ? 'Yes' : '-'); ?>

- Makeup Artists: <?php echo e($getCustomer['orders']->makeup_artists == 1 ? 'Yes' : '-'); ?>

- Venues: <?php echo e($getCustomer['orders']->venues == 1 ? 'Yes' : '-'); ?>

- Hall Decorators: <?php echo e($getCustomer['orders']->hall_decorators == 1 ? 'Yes' : '-'); ?>

- Phototographers: <?php echo e($getCustomer['orders']->photographers_video == 1 ? 'Yes' : '-'); ?>

- Aso Ebi: <?php echo e($getCustomer['orders']->aso_ebi == 1 ? 'Yes' : '-'); ?>

- Printers: <?php echo e($getCustomer['orders']->printers == 1 ? 'Yes' : '-'); ?>

- Souvenirs: <?php echo e($getCustomer['orders']->souvenirs_gifts == 1 ? 'Yes' : '-'); ?>



**Total Amount:** ₦<?php echo e(number_format($payment_verification['price'])); ?>


**This amount shown is for the Limo order service only. All other services aside it will be discussed soon. Also, payment for any damages will
be deducted from this amount. Otherwise the damage fee will be paid back to you.
**


Your order is now being processed. If you have any questions or need further assistance, please don't hesitate to reach out to our support team.

Thank you for choosing Victruth!

Sincerely,<br>
The Victruth Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\victruth\backend\resources\views\emails\users\confirmuserpayment.blade.php ENDPATH**/ ?>